package com.example.ui_main;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

import java.io.IOException;

public class HelloController2 {
    @FXML
    private ImageView Hero;
    @FXML
    private Button pause_button;
    private double sl=0.0;


    @FXML
    public void initialize(){
        create_stick();

    }

    private void create_stick() {

    }

    public void exit(ActionEvent event) throws IOException {
        HelloApplication h = new HelloApplication();
        h.changeScene("exit.fxml");
    }

    private void hero_animation() {
        Timeline t=new Timeline();
        Hero.setTranslateX(0);
        KeyFrame keyFrame=new KeyFrame(Duration.seconds(2),new KeyValue(Hero.translateXProperty(),200));
        t.getKeyFrames().add(keyFrame);
        t.setCycleCount(Timeline.INDEFINITE);
        t.play();
    }


}

