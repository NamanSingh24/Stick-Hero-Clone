package com.example.stickherogame;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

class Stick {
    private double length;
    private boolean growing;

    private static final double MAX_LENGTH = 200; // Adjust the maximum length

    public Stick() {
        this.length = 0;
        this.growing = false;
    }

    public void startGrowing() {
        this.growing = true;
    }

    public void stopGrowing() {
        this.growing = false;
    }

    public void fall() {
        // Reset length after falling
        this.length = 0;
    }

    public void update() {
        // Update the stick's length
        if (growing && length < MAX_LENGTH) {
            length += 2; // Adjust growth speed as needed
        }
    }

    public void render(GraphicsContext gc, double playerX, double playerY, double playerWidth) {
        gc.setFill(Color.BROWN); // Set stick color
        gc.fillRect(playerX + playerWidth / 2, playerY, 5, length); // Draw the stick
    }

    public boolean fallOnMidpoint(double pillarX, double pillarMidpoint, double pillarWidth) {
        double stickEndX = pillarX + pillarWidth / 2;
        return length > pillarMidpoint && length < pillarMidpoint + 5 && stickEndX > pillarX && stickEndX < pillarX + pillarWidth;
    }

    public boolean isGrowing() {
        return growing;
    }

    public double getLength() {
        return 0;
    }
}