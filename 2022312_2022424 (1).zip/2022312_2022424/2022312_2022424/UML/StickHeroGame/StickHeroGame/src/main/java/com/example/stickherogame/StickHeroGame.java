package com.example.stickherogame;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static javafx.scene.layout.BorderPane.setAlignment;



public class StickHeroGame extends Application {


    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {



    }

    public void playStickIncreaseSound() {

    }

    public void playPlayerRunningSound() {

    }

    public void playGameOverSound() {

    }

    public void playCharacterFallingSound() {

    }

    public void render() {

    }

    public double getHeight() {
        return 0;
    }

    public double getWidth() {
        return 0;
    }

    public GraphicsContext getGraphicsContext2D() {
        return null;
    }

    static class GameOverPopup extends VBox {
        public GameOverPopup(int currentScore, int bestScore, Runnable onRestart, Runnable onHome) {
            setSpacing(10);
            setAlignment(Pos.CENTER);

            Text gameOverText = new Text("Game Over");
            gameOverText.setFont(Font.font(24));

            Text currentScoreText = new Text("Current Score: " + currentScore);
            Text bestScoreText = new Text("Best Score: " + bestScore);

            Button restartButton = new Button("Restart");
            restartButton.setOnAction(event -> onRestart.run());

            Button homeButton = new Button("Home");
            homeButton.setOnAction(event -> onHome.run());

            getChildren().addAll(gameOverText, currentScoreText, bestScoreText, restartButton, homeButton);
        }
    }

    static class MainMenu extends Pane {
        public MainMenu(Stage primaryStage) {
            Button playButton = new Button("Play");

            playButton.setOnAction(event -> {
                // Start the game when the play button is clicked
                startGame(primaryStage);
            });

            getChildren().add(playButton);
            setAlignment(playButton, Pos.CENTER);
        }

        private void startGame(Stage primaryStage) {
        }

        public void start(Stage primaryStage) {
            primaryStage.setTitle("Stick Hero Game");

            MainMenu mainMenu = new MainMenu(primaryStage);

            StickHeroGame stickHeroGame = new StickHeroGame();

            GameWorld gameWorld = new GameWorld();
            Pane root = new Pane(gameWorld);
            Scene scene = new Scene(root, 800, 600);

            scene.setOnMousePressed(event -> {
                if (event.getButton() == MouseButton.PRIMARY) {
                    gameWorld.startStickGrowth();
                }
            });

            scene.setOnMouseReleased(event -> {
                if (event.getButton() == MouseButton.PRIMARY) {
                    gameWorld.releaseStick();
                }
            });

            primaryStage.setScene(scene);
            primaryStage.show();

            gameWorld.startGame(stickHeroGame); // Pass the stickHeroGame instance
        }

    }

    static class GameWorld extends Canvas {
        private Player stickHero;
        private List<Pillar> pillars;
        private int score;
        private int bestScore;
        private VBox uiContainer;
        private StickHeroGame stickHeroGame;

        private static final double PILLAR_GAP = 300;
        private static final double MIN_PILLAR_WIDTH = 50;
        private static final double MAX_PILLAR_WIDTH = 150;

        public GameWorld() {
            super(800, 600);
            // Initialize game objects
            stickHero = new Player();
            pillars = new ArrayList<>();
            pillars.add(generatePillar());
            pillars.add(generatePillar());
            score = 0;
            bestScore = 0;

            // Create UI container
            uiContainer = new VBox();
        }

        public void startGame(StickHeroGame stickHeroGame) {
            this.stickHeroGame = stickHeroGame;

            // Start the game loop
            new AnimationTimer() {
                long lastUpdate = 0;

                @Override
                public void handle(long now) {
                    if (now - lastUpdate >= 16_666_667) {
                        update();
                        render();
                        lastUpdate = now;
                    }
                }
            }.start();
        }

        public void update() {
            stickHero.update();
            checkCollisions();
            updatePillars();
            checkCherryCollection();
            playSounds(); // Play sounds at appropriate places
            if (gameOver()) {
                showGameOverPopup();
            }
        }

        public void playSounds() {

        }

        public void checkCollisions() {

            double playerX = stickHero.getX();
            double stickLength = stickHero.getStick().getLength();


            // Check if the stick is less than or more than another pillar
            for (Pillar pillar : pillars) {
                double leftEdge = getWidth() / 2 - pillar.getWidth() / 2;
                double rightEdge = leftEdge + pillar.getWidth();

                if (stickLength < leftEdge || stickLength > rightEdge) {
                    gameOver();
                }
            }
        }

        public void updatePillars() {
            // Update pillar positions
            for (Pillar pillar : pillars) {
                pillar.setWidth(pillar.getWidth() - 2);
                if (pillar.getWidth() <= 0) {
                    pillars.remove(pillar);
                    pillars.add(generatePillar());
                    score++; // Increase the score
                }
            }
        }

        public void checkCherryCollection() {
            if (playerIsCollidingWithCherry()) {
                int previousScore = score;
                stickHero.collectCherry();
                int currentScore = score;

                if (currentScore > previousScore) {
//                    totalCherries++; // Increment total cherries count only if the player scored at least 1 point
                }
            }
        }

        public boolean playerIsCollidingWithCherry() {
            return false;
        }

        public void render() {
            GraphicsContext gc = getGraphicsContext2D();
            // Clear canvas
            gc.clearRect(0, 0, getWidth(), getHeight());
            stickHero.render(gc, uiContainer);
            renderPillars(gc);
            renderUI();
        }

        public void renderUI() {
            uiContainer.setLayoutX(getWidth() - 100); // Adjust the layout as needed
            uiContainer.setLayoutY(20);
//            getChildren().add(uiContainer);
        }

        public void renderPillars(GraphicsContext gc) {
            // Render pillars on the canvas
            for (Pillar pillar : pillars) {
                double x = getWidth() / 2 - pillar.getWidth() / 2;
                double y = getHeight() - PILLAR_GAP;
                double height = PILLAR_GAP;
                gc.setFill(Color.GREEN); // Set pillar color
                gc.fillRect(x, y, pillar.getWidth(), height); // Draw the pillar

                // Check if the stick falls on the midpoint of the pillar
                if (stickHero.getStick().fallOnMidpoint(x, pillar.getMidpoint(), pillar.getWidth())) {
                    // Player gets one extra point
                    score++;
                }
            }
        }

        public Pillar generatePillar() {
            double width = MIN_PILLAR_WIDTH + Math.random() * (MAX_PILLAR_WIDTH - MIN_PILLAR_WIDTH);
            double midpoint = Math.random() * (PILLAR_GAP - 2 * MIN_PILLAR_WIDTH) + MIN_PILLAR_WIDTH;
            return new Pillar(width, midpoint);
        }

        public boolean gameOver() {
            // Handle game over
            int currentScore = stickHero.getCollectedCherries() + score;

            // Check if the current score is greater than the best score
            if (currentScore > bestScore) {
                bestScore = currentScore;
            }

            // Display the Game Over
            GameOverPopup gameOverPopup = new GameOverPopup(currentScore, bestScore, this::restartGame, this::goToHomePage);

            // Position the popup in the center
            gameOverPopup.setLayoutX((getWidth() - gameOverPopup.getWidth()) / 2);
            gameOverPopup.setLayoutY((getHeight() - gameOverPopup.getHeight()) / 2);

//            getChildren().add(gameOverPopup);

            // Play the game over sound
//            playGameOverSound();

            // Stop further updates
            return true;
        }

        private Calendar getChildren() {
            return null;
        }


        public void showGameOverPopup() {

        }

        public void restartGame() {
            // Reset game state and start a new game
            pillars.clear();
            pillars.add(generatePillar());
            pillars.add(generatePillar());
            score = 0;
            stickHero = new Player();
        }

        public void goToHomePage() {

            System.exit(0);
        }

        public Player getStickHero() {
            return stickHero;
        }

        public void setStickHero(Player stickHero) {
            this.stickHero = stickHero;
        }

        public List<Pillar> getPillars() {
            return pillars;
        }

        public void setPillars(List<Pillar> pillars) {
            this.pillars = pillars;
        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public int getBestScore() {
            return bestScore;
        }

        public void setBestScore(int bestScore) {
            this.bestScore = bestScore;
        }

        public VBox getUiContainer() {
            return uiContainer;
        }

        public void setUiContainer(VBox uiContainer) {
            this.uiContainer = uiContainer;
        }

        public StickHeroGame getStickHeroGame() {
            return stickHeroGame;
        }

        public void setStickHeroGame(StickHeroGame stickHeroGame) {
            this.stickHeroGame = stickHeroGame;
        }

        public static double getPillarGap() {
            return PILLAR_GAP;
        }

        public static double getMinPillarWidth() {
            return MIN_PILLAR_WIDTH;
        }

        public static double getMaxPillarWidth() {
            return MAX_PILLAR_WIDTH;
        }

        public void startStickGrowth() {
        }

        public void releaseStick() {
        }
    }
}
