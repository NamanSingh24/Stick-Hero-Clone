package com.example.stickherogame;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;

class Player {
    private double x;
    private double y;
    private Stick stick;
    private int collectedCherries;
    private int totalCherries;

    private static final double PLAYER_WIDTH = 20;
    private static final double PLAYER_HEIGHT = 40;

    public Player() {
        // Initial position and stick creation
        x = 400; // Adjust the starting x-coordinate
        y = 500; // Adjust the starting y-coordinate
        stick = new Stick();
        collectedCherries = 0;
        totalCherries = 0;
//        characterPhoto = new Image(getClass().getResourceAsStream("/resources/character_photo.png"));
        this.stick = new Stick();
    }

    public void update() {

    }

    public void render(GraphicsContext gc, VBox uiContainer) {
        gc.setFill(Color.BLUE); // Set player color
        gc.fillRect(x, y - PLAYER_HEIGHT, PLAYER_WIDTH, PLAYER_HEIGHT); // Draw the player
        // Draw the stick
        stick.render(gc, x, y, PLAYER_WIDTH);

        renderUI(uiContainer);
    }

    public void renderUI(VBox uiContainer) {
        // Display the total cherries
        uiContainer.getChildren().clear(); // Clear previous UI elements
        uiContainer.getChildren().add(new Text("Cherries: " + totalCherries));

        // Display the revive button if the player has enough cherries
        if (totalCherries >= 2) {
            Button reviveButton = new Button("Revive");
            reviveButton.setOnAction(event -> revive());
            uiContainer.getChildren().add(reviveButton);
        }
    }

    public void revive() {
        // Deduct 2 cherries and implement revive logic
        if (totalCherries >= 2) {
            totalCherries -= 2;
        }
    }

    public int getCollectedCherries() {
        return collectedCherries;
    }

    public void collectCherry() {
        collectedCherries++;
        totalCherries++; // Increment total cherries count
    }

    public Stick getStick() {
        return stick;
    }

    public double getX() {
        return 0;
    }

}