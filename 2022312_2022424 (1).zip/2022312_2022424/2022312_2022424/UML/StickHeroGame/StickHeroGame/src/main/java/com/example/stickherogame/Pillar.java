package com.example.stickherogame;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import java.util.ArrayList;
import java.util.List;


public class Pillar{
    private double width;
    private double midpoint;

    public Pillar(double width, double midpoint) {
        this.width = width;
        this.midpoint = midpoint;
    }

    public double getWidth() {
        return width;
    }

    public double getMidpoint() {
        return midpoint;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public void increaseWidth(double increment) {
        // Increase the width of the pillar by a certain amount
        this.width += increment;
    }

    public void decreaseWidth(double decrement) {
        // Decrease the width of the pillar
        this.width -= decrement;
        if (this.width < 0) {
            this.width = 0; // Ensure the width doesn't go below 0
        }
    }

    public boolean isCollidingWithPlayer(Player player) {

        return false;
    }
}